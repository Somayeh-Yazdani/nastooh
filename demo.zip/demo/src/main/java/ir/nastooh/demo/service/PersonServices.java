package ir.nastooh.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import ir.nastooh.demo.model.dao.PersonDao;
import ir.nastooh.demo.model.entity.Person;


@Service
public class PersonServices {

	public PersonDao personDao ;

	@Autowired
	public PersonServices(PersonDao personDao) {
		this.personDao = personDao;
	}

	@Transactional
	public Integer save(Person person) {
		Integer personId = -1;
		Person savedPerson = personDao.save(person);
		personId = savedPerson.getPersonId();
		return personId;
	}


	@Transactional
	public void deleteById(Integer id) {
		personDao.deleteById(id);
	}

	@Transactional
	public List<Person> findAll(){
		return personDao.findAll();
	}

	@Transactional
	public Person findById(Integer id){
		Optional<Person> person = personDao.findById(id);
		if(person.isPresent())
			return person.get();
		else
			return null;
	}
	
}
