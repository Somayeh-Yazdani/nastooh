package ir.nastooh.demo.model.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ir.nastooh.demo.model.entity.Expertize;
import ir.nastooh.demo.model.entity.Person;


@Repository
public interface ExpertizeDao extends CrudRepository<Expertize, Integer> ,JpaSpecificationExecutor<Expertize>{
	Expertize save(Expertize e);
	List<Expertize> findAll();
	Optional<Expertize> findById(Integer id);
	void deleteById(Integer id) ;
	@Query("select e from Expertize e where e.person.personId =:personId")
	Optional<List<Expertize>> findByPerson(@Param("personId") Integer personId);
	
}
