package ir.nastooh.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ir.nastooh.demo.model.dao.ExpertizeDao;
import ir.nastooh.demo.model.entity.Expertize;


@Service
public class ExpertizeServices {

	public ExpertizeDao expertizeDao ;

	@Autowired
	public ExpertizeServices(ExpertizeDao expertizeDao) {
		this.expertizeDao = expertizeDao;
	}
	
	
	
	@Transactional
	public Integer save(Expertize expertize) {
		Integer expertizeId = -1;
		Expertize savedExpertize = expertizeDao.save(expertize);
		expertizeId = savedExpertize.getExpertizeId();
		return expertizeId;
	}


	@Transactional
	public void deleteById(Integer id) {
		expertizeDao.deleteById(id);
	}

	@Transactional
	public List<Expertize> findAll(){
		return expertizeDao.findAll();
	}

	@Transactional
	public Expertize findById(Integer id){
		Optional<Expertize> expertize = expertizeDao.findById(id);
		if(expertize.isPresent())
			return expertize.get();
		else
			return null;
	}
	
	@Transactional
	public List<Expertize> findByPerson(Integer personId){
		Optional<List<Expertize>> expertize = expertizeDao.findByPerson(personId);
		if(expertize.isPresent())
			return expertize.get();
		else
			return null;
	}
}
