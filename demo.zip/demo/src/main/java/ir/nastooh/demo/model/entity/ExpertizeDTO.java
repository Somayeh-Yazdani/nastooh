package ir.nastooh.demo.model.entity;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
public class ExpertizeDTO {
	private Integer expertizeId;
	private String nameExp;
	private String durationHavingDegree;
	private String dateOfReceiptDegree;
	private String description;
	private Integer personId;


}