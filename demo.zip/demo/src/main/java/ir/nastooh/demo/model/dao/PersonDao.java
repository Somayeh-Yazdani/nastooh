package ir.nastooh.demo.model.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ir.nastooh.demo.model.entity.Person;


@Repository
public interface PersonDao extends CrudRepository<Person, Integer> ,JpaSpecificationExecutor<Person>{
	Person save(Person p);
	@Query("select p from Person p where nationalCode =:nationalCode")
	Optional<Person> findByNationalCode(@Param("nationalCode") String nationalCode);
	List<Person> findAll();
	Optional<Person> findById(Integer id);
	@Modifying
    @Query("update Person set name=:newName where personId=:id")
    void update(@Param("id") Integer id, @Param("newName") String name);
	void deleteById(Integer id) ;
}
