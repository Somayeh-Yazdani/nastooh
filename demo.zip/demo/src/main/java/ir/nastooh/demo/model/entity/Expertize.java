package ir.nastooh.demo.model.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
public class Expertize {
	@Id@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer expertizeId;
	private String nameExp;
	private String durationHavingDegree;
	private String dateOfReceiptDegree;
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "personId")
	private Person person;

	public Integer getExpertizeId() {
		return expertizeId;
	}

	public void setExpertizeId(Integer expertizeId) {
		this.expertizeId = expertizeId;
	}

	public String getNameExp() {
		return nameExp;
	}

	public void setNameExp(String nameExp) {
		this.nameExp = nameExp;
	}

	public String getDurationHavingDegree() {
		return durationHavingDegree;
	}

	public void setDurationHavingDegree(String durationHavingDegree) {
		this.durationHavingDegree = durationHavingDegree;
	}

	public String getDateOfReceiptDegree() {
		return dateOfReceiptDegree;
	}

	public void setDateOfReceiptDegree(String dateOfReceiptDegree) {
		this.dateOfReceiptDegree = dateOfReceiptDegree;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}
	
}