package ir.nastooh.demo.model.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.OneToMany;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PersonDTO {

	private Integer personId;
	private String name;
	private String family;
	private int gender;
	private Integer age;
	private boolean nationality;
	private String nationalCode;
	private String birthDate;
	private String expertizeList;
}
