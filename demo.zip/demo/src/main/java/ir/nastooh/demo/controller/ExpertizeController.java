package ir.nastooh.demo.controller;

import java.util.List;

import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import ir.nastooh.demo.model.entity.Expertize;
import ir.nastooh.demo.model.entity.ExpertizeDTO;
import ir.nastooh.demo.model.entity.Person;
import ir.nastooh.demo.service.ExpertizeServices;
import ir.nastooh.demo.service.PersonServices;

@Controller
@RequestMapping("/")
public class ExpertizeController {

	@Autowired
	ExpertizeServices expertizeServices;
	
	@Autowired
	private ModelMapper modelMapper;


	@Autowired
	PersonServices personServices;

	@RequestMapping(value = "show_all_expertize", method = RequestMethod.GET)
	public ModelAndView findAll(@RequestParam Integer personId  ,Model model) {
		ModelAndView mv = new ModelAndView("allExpertize");
		List<Expertize> result = expertizeServices.findByPerson(personId);
		mv.addObject("expertizeList", result);
		return  mv;
	}
	
	@RequestMapping(value = "newExpertize", method = RequestMethod.GET)
	public String newExpertize(@RequestParam Integer personId  ,@RequestParam Integer expertizeId  ,Model model) {
		ExpertizeDTO e = new ExpertizeDTO();
		if(expertizeId != -1) {
    		Expertize expertize = expertizeServices.findById(expertizeId);
    		e.setExpertizeId(expertize.getExpertizeId());
    		e.setDateOfReceiptDegree(expertize.getDateOfReceiptDegree());
    		e.setDescription(expertize.getDescription());
    		e.setDurationHavingDegree(expertize.getDurationHavingDegree());
    		e.setNameExp(expertize.getNameExp());
    		e.setPersonId(expertize.getPerson().getPersonId());
    		
    	}
		model.addAttribute("expertize", e);
		return "newExpertize";
	}

	@RequestMapping(value = "saveExpertize", method = RequestMethod.POST)
	public String saveExpertize(@ModelAttribute("expertize") ExpertizeDTO expertizeDTO) {
    	Person person = personServices.findById(expertizeDTO.getPersonId());
    	Expertize newExp = new Expertize();
    	newExp.setDateOfReceiptDegree(expertizeDTO.getDateOfReceiptDegree());
    	newExp.setDescription(expertizeDTO.getDescription());
    	newExp.setDurationHavingDegree(expertizeDTO.getDurationHavingDegree());
    	newExp.setExpertizeId(expertizeDTO.getExpertizeId());
    	newExp.setNameExp(expertizeDTO.getNameExp());
    	newExp.setPerson(person);
    	expertizeServices.save(newExp);
    	return "redirect:show_all_expertize?personId="+expertizeDTO.getPersonId();
	}
	
	
	@RequestMapping(value = "deleteExpertize", method = RequestMethod.GET)
    public String delete( Integer id,Model model) {
			Integer personId = expertizeServices.findById(id).getPerson().getPersonId();
			expertizeServices.deleteById(id);
            return "redirect:show_all_expertize?personId=" + personId;
    }
}
