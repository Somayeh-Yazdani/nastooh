package ir.nastooh.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ir.nastooh.demo.model.entity.Expertize;
import ir.nastooh.demo.model.entity.Person;
import ir.nastooh.demo.model.entity.PersonDTO;
import ir.nastooh.demo.service.ExpertizeServices;
import ir.nastooh.demo.service.PersonServices;

@Controller
@RequestMapping("/")
public class PersonController {

	public PersonServices personServices;

	@Autowired
	ExpertizeServices expertizeServices;
	@Autowired
	public PersonController(PersonServices personServices) {
		this.personServices = personServices;
	}

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String getHomePage() {
		return "home";
	}

	@RequestMapping(value = "new", method = RequestMethod.GET)
	public String showRegister(@RequestParam Integer personId, Model model) {
		// new
		if (personId == -1) {
			Person p = new Person();
			p.setPersonId(-1);
			model.addAttribute("person", p);
		}
		// edit
		else
			model.addAttribute("person", personServices.findById(personId));
		return "new";
	}

	@RequestMapping(value = "save", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("person") PersonDTO person) {
		Person p = new Person();
		if(person.getPersonId() != -1)
			p.setPersonId(person.getPersonId());
		p.setAge(person.getAge());
		p.setBirthDate(person.getBirthDate());
		p.setFamily(person.getFamily());
		p.setGender(person.getGender());
		p.setName(person.getName());
		p.setNationalCode(person.getNationalCode());
		p.setNationality(person.isNationality());
		personServices.save(p);
		List<Expertize> expertizeList = expertizeServices.findByPerson(person.getPersonId());
		for (int i = 0; i < expertizeList.size(); i++) {
			expertizeList.get(i).setPerson(p);
			expertizeServices.save(expertizeList.get(i));
		}
		return "redirect:show_all";
	}

	@RequestMapping(value = "show_all", method = RequestMethod.GET)
	public String findAll(Model model) {
		List<Person> result = personServices.findAll();
		model.addAttribute("persons", result);
		return "allPerson";
	}

	@RequestMapping(value = "delete", method = RequestMethod.GET)
	public String delete(Integer personId, Model model) {
		personServices.deleteById(personId);
		return "forward:show_all";
	}

	@RequestMapping(value = "search", method = RequestMethod.GET)
	public String showSearchPage(Model model) {
		model.addAttribute("person", new Person());
		return "search";
	}

}
